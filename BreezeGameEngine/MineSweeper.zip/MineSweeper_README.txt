MINESWEEPER

SELECT DIFFICULTY:

At menu, use Q, W, E to select game difficulty.
Clicking the appropriate text also works.

GAME PLAY

The first selected tile will always have 0 adjacent mines.

Any tile with no adjacent mines opens all adjacent tiles automatically.

Number of adjacent tiles is indicated by color (Red, Orange, Yellow, Green, L.Blue, Blue, Magenta, Black)

This is also indicated at the bottom of the game play screen.

Right click on covered tiles sets indicator (None -> Mine -> Suspsicious)

Cells marked as mines may not be clicked.

If the appropriate number of tiles are marked as mines, double clicking the tile uncovers adjacent tiles which are not marked as bombs)

Uncovering a bomb displays a score in the top right (this is the number of CORRECTLY marked mines), but gameplay may continue to experiment

Victory is not currently explicitly noted, but can be determined by having only marked tiles of the appropriate number (noted in top left)

Clicking quit or pressing ESC returns to the title.

Enjoy